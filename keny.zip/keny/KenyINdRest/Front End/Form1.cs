using System;
using MySql.Data.MySqlClient; // Import Statement for connecting C# to MySQL client
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;

namespace Front_End
{
    public partial class Form1 : Form
    {

        public static MySql.Data.MySqlClient.MySqlConnection? conn;
        public static MySqlCommand? cmd;
        public static MySqlDataReader? reader;

        public static string MyConnectionstring { get; private set; }

       
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Employee employeeForm = new Employee(); // Create a new instance of EmployeeForm
            employeeForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Customer employeeForm = new Customer(); // Create a new instance of EmployeeForm
            employeeForm.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}