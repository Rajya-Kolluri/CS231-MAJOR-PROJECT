﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Front_End
{

    public partial class Customer : Form
    {
        public static MySql.Data.MySqlClient.MySqlConnection? conn;
        public static MySqlCommand? cmd;
        public static MySqlDataReader? reader;
        public static void sqlopener()
        {
            String myConnectionstring;
            string? MySql_Password = "collins1237Q#@";
            myConnectionstring = "SERVER=localhost;DATABASE=KenyINd;UID=root;PASSWORD='" + MySql_Password + "';";
            try
            {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = myConnectionstring;
                conn.Open();

            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static MySql.Data.MySqlClient.MySqlConnection closeSQL()
        {
            conn.Close();
            return conn;

        }
        public Customer()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string username, userpass;
            username = txtusername.Text;
            userpass = txtpass.Text;
            string query = "select * from login where username=@username and password=@password;";
            List<Logintable>loginlist= new List<Logintable>();
            sqlopener();
            cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password" ,userpass);
            reader= cmd.ExecuteReader();

            while (reader.Read())
            {
                Logintable login= new Logintable();
                login.username = Convert.ToString(reader["username"]);
                login.password = Convert.ToString(reader["password"]);
                loginlist.Add(login);
            }
            conn=closeSQL();

            if (loginlist.Count > 0)
            {
                Customerorders orders = new Customerorders();
                orders.Show();
            }

        }

        private void btnback_Click(object sender, EventArgs e)
        {

        }
    }
}
