﻿create database KenyINd;
use KenyInd;
create table login(username varchar(10) not null, password varchar (50) not null);
insert into login( username, password) values('ckipruto', 'goon123');
create table KenyindRes(ResId int primary key, Reslocation varchar(50), ResPhone varchar(30), ResEmail varchar(50));
insert into KenyindRes(ResID, Reslocation, Resphone) values('001', 'Hooksett', '6033381650');
create table Chef(Chefid int primary key, chefname varchar (225), chefSpeciality varchar (225), menuID int);
CREATE TABLE Menu (MenuID INT PRIMARY KEY, MenuName VARCHAR(60), MenuDesc VARCHAR(200), ChefID INT, FOREIGN KEY (ChefID) REFERENCES Chef(ChefID));
CREATE TABLE Category (CategoryID INT PRIMARY KEY, CategoryName VARCHAR(255), MenuID int);
CREATE TABLE Item ( ItemID INT PRIMARY KEY, ItemName VARCHAR(255), ItemDescription VARCHAR(255),  ItemPrice DECIMAL(10,2),  CategoryID INT,  MenuID INT,  FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),FOREIGN KEY (MenuID) REFERENCES Menu(MenuID));
CREATE TABLE Customer ( CustomerID INT PRIMARY KEY, CustomerName VARCHAR(255), CustomerPhoneNumber VARCHAR(20),  CustomerEmail VARCHAR(255));
CREATE TABLE Orders( OrderID INT PRIMARY KEY, OrderDate DATE, OrderTime TIME, OrderTotal DECIMAL(10,2), CustomerID INT,  FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID));
CREATE TABLE OrderItem(OrderID int,ItemID int,ResID int,
FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
  FOREIGN KEY (ItemID) REFERENCES Item(ItemID),
  FOREIGN KEY (ResID) REFERENCES KenyindRes(ResID)
);
USE KenyInd;
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_Name='KenyindRes';

